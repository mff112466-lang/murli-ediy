MURLI EDIT SETUP (Hinglish)

1) Is ZIP ke andar ka content apne GitHub repo ke ROOT mein upload/push karo. Purani files ka backup pehle rakho.
2) Netlify mein Build publish directory = public aur Functions directory = netlify/functions rakho. netlify.toml ye set karta hai.
3) Netlify Site configuration > Environment variables mein ye add karo:
   RAZORPAY_KEY_ID = Razorpay TEST Key ID
   RAZORPAY_KEY_SECRET = Razorpay TEST Key Secret (Contains secret values ON)
   ADMIN_PASSWORD = ek lamba, unique owner password (secret ON)
4) Save karke site redeploy karo.
5) Site par Owner dabao, ADMIN_PASSWORD enter karo, products add karo. PNG/JPG/WebP image approx 2 MB tak.
6) Test Mode checkout test karo. Live keys tabhi use karo jab guardian ke saath merchant account KYC/activation complete ho.

IMPORTANT LIMITATIONS:
- Payment gateway code order create karta hai aur Razorpay signature server par verify karta hai. Real payment ke liye Razorpay account approval/KYC zaroori hai.
- Settlement Razorpay ke settlement schedule aur linked bank account par hota hai; code settlement ko force nahi kar sakta.
- Is starter mein secure ZIP/RAR delivery, order database, refunds, invoices, webhook reconciliation aur fraud/rate limiting abhi included nahi hain. Isliye paid ZIP downloads ko live sell karne se pehle secure delivery add aur test karna zaroori hai.
- Product prices frontend se nahi, production mein server-side product records se verify hone chahiye; is starter ko public live store ke liye aur harden karna baaki hai.
- Secret key, password, OTP kisi ko mat bhejna. Parent/guardian se payment account/KYC manage karwao.

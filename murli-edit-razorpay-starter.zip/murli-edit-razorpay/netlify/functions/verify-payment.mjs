import crypto from "node:crypto";
const out=(x,s=200)=>new Response(JSON.stringify(x),{status:s,headers:{"content-type":"application/json"}});
export default async req=>{
 if(req.method!=="POST")return out({error:"Method not allowed"},405);
 try{
  const b=await req.json(),secret=process.env.RAZORPAY_KEY_SECRET;
  if(!secret||!b.razorpay_order_id||!b.razorpay_payment_id||!b.razorpay_signature)return out({error:"Missing payment details."},400);
  const expected=crypto.createHmac("sha256",secret).update(b.razorpay_order_id+"|"+b.razorpay_payment_id).digest("hex");
  const a=Buffer.from(expected),c=Buffer.from(String(b.razorpay_signature));
  if(a.length!==c.length||!crypto.timingSafeEqual(a,c))return out({verified:false,error:"Signature invalid."},400);
  return out({verified:true,message:"Payment verified."});
 }catch{return out({verified:false,error:"Verification failed."},400);}
};
export const config={path:"/api/verify-payment"};
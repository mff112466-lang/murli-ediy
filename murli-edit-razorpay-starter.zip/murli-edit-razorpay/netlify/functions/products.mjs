import { getStore } from "@netlify/blobs";
const db=()=>getStore("murli-products");
const out=(x,s=200)=>new Response(JSON.stringify(x),{status:s,headers:{"content-type":"application/json","cache-control":"no-store"}});
export default async req=>{
 const store=db();
 if(req.method==="GET") return out((await store.get("items",{type:"json"}))||[]);
 if(req.method!=="POST") return out({error:"Method not allowed"},405);
 if(!process.env.ADMIN_PASSWORD || req.headers.get("x-admin-password")!==process.env.ADMIN_PASSWORD) return out({error:"Unauthorized"},401);
 try{
  const b=await req.json(); let a=(await store.get("items",{type:"json"}))||[];
  if(b.action==="check") return out({ok:true});
  if(b.action==="delete"){await store.setJSON("items",a.filter(x=>x.id!==b.id));return out({ok:true});}
  const name=String(b.name||"").trim().slice(0,90),price=Number(b.price),description=String(b.description||"").slice(0,500),image=String(b.image||"");
  if(!name||!Number.isFinite(price)||price<1||price>100000)return out({error:"Valid name and price required."},400);
  if(image && (!image.startsWith("data:image/")||image.length>2800000))return out({error:"Image must be PNG/JPG/WebP under about 2 MB."},400);
  const id=b.id||crypto.randomUUID(),p={id,name,price,description,image};
  a=b.action==="edit"?a.map(x=>x.id===id?p:x):[...a,p];await store.setJSON("items",a);return out({ok:true});
 }catch{return out({error:"Could not save product."},400);}
};
export const config={path:"/api/products"};
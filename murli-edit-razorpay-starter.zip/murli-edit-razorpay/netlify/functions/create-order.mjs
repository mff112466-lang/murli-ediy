const out=(x,s=200)=>new Response(JSON.stringify(x),{status:s,headers:{"content-type":"application/json"}});
export default async req=>{
 if(req.method!=="POST")return out({error:"Method not allowed"},405);
 const id=process.env.RAZORPAY_KEY_ID,secret=process.env.RAZORPAY_KEY_SECRET;
 if(!id||!secret)return out({error:"Razorpay keys are not configured."},500);
 try{
  const b=await req.json(),paise=Math.round(Number(b.amount)*100);
  if(!Number.isInteger(paise)||paise<100||paise>10000000)return out({error:"Invalid amount."},400);
  const r=await fetch("https://api.razorpay.com/v1/orders",{method:"POST",headers:{authorization:"Basic "+Buffer.from(id+":"+secret).toString("base64"),"content-type":"application/json"},body:JSON.stringify({amount:paise,currency:"INR",receipt:"murli_"+Date.now()})});
  const o=await r.json();if(!r.ok)return out({error:"Razorpay order creation failed."},502);
  return out({orderId:o.id,amount:o.amount,currency:o.currency,keyId:id});
 }catch{return out({error:"Could not create order."},500);}
};
export const config={path:"/api/create-order"};